EVENT SUPPORT BFN – PHONE INSTALLABLE APP

Files to upload to the ROOT of your GitHub repository:
- index.html
- manifest.webmanifest
- sw.js
- icon-192.png
- icon-512.png

Then enable GitHub Pages: Settings > Pages > Deploy from a branch > main > /(root) > Save.
The app can then be opened from the GitHub Pages link and installed from Chrome using Add to Home screen / Install app.

IMPORTANT: inspection records are currently stored on the phone/browser using local storage. This package does not provide cloud synchronization between phones.
